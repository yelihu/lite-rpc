package org.example.rpc.common;

/**
 * @author yelihu
 */
public abstract class PortConst {

    public static final int _8080 = 8080;

}
